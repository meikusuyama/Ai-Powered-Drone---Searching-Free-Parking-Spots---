#ifndef TCP_CLIENT_H_
#define TCP_CLIENT_H_

#include "cy_result.h"
#include "cyabs_rtos.h"

/* Task configuration */
#define TCP_CLIENT_TASK_STACK_SIZE  (configMINIMAL_STACK_SIZE * 10)
#define TCP_CLIENT_TASK_PRIORITY    (configMAX_PRIORITIES - 1)

/* Function prototypes */
void tcp_client_task(void *arg);
cy_rslt_t create_tcp_client_task(void);

/* Global semaphore to signal when TCP client is ready */
extern cy_semaphore_t tcp_ready;

/* Utility for sending alert */
void tcp_client_send_siren_alert(void);

#endif /* TCP_CLIENT_H_ */
