/* Header file includes. */
#include "cyhal.h"
#include "cybsp.h"
#include "cy_retarget_io.h"

/* RTOS header file. */
#if defined (COMPONENT_FREERTOS)
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <timers.h>
#endif

/* TCP client task header file. */
#include "tcp_client.h"
#include "audio.h"

/* Include serial flash library and QSPI memory configurations only for the
 * kits that require the Wi-Fi firmware to be loaded in external QSPI NOR flash.
 */
#if defined(CY_DEVICE_PSOC6A512K)
#include "cy_serial_flash_qspi.h"
#include "cycfg_qspi_memslot.h"
#endif

/*******************************************************************************
* Macros
********************************************************************************/
/* RTOS related macros. */
#if defined (COMPONENT_FREERTOS)
#define TCP_CLIENT_TASK_STACK_SIZE        (5 * 1024)
#define TCP_CLIENT_TASK_PRIORITY          (1)
#endif

/*******************************************************************************
* Global Variables
********************************************************************************/
/* This enables RTOS aware debugging. */
volatile int uxTopUsedPriority;

/********************************************************************************
 * Function Name: main
 ********************************************************************************
 * Summary:
 *  System entrance point. This function sets up user tasks and then starts
 *  the RTOS scheduler.
 *
 * Parameters:
 *  void
 *
 * Return:
 *  int
 *
 *******************************************************************************/
int main(void)
{
    cy_rslt_t result;

    /* Initialize the device and board peripherals */
    result = cybsp_init();
    if (result != CY_RSLT_SUCCESS)
    {
        CY_ASSERT(0);
    }

    /* Enable global interrupts */
    __enable_irq();

    /* Initialize retarget-io to use the debug UART port. */
    cy_retarget_io_init(CYBSP_DEBUG_UART_TX, CYBSP_DEBUG_UART_RX,
                        CY_RETARGET_IO_BAUDRATE);

    /* Initialize the User LED. */
    cyhal_gpio_init(CYBSP_USER_LED, CYHAL_GPIO_DIR_OUTPUT,
                    CYHAL_GPIO_DRIVE_STRONG, CYBSP_LED_STATE_OFF);

#if defined(CY_DEVICE_PSOC6A512K)
    const uint32_t bus_frequency = 50000000lu;
    cy_serial_flash_qspi_init(smifMemConfigs[0], CYBSP_QSPI_D0, CYBSP_QSPI_D1,
                              CYBSP_QSPI_D2, CYBSP_QSPI_D3, NC, NC, NC, NC,
                              CYBSP_QSPI_SCK, CYBSP_QSPI_SS, bus_frequency);

    /* Enable the XIP mode to get the Wi-Fi firmware from the external flash. */
    cy_serial_flash_qspi_enable_xip(true);
#endif

    /* Clear screen and print header */
    printf("\x1b[2J\x1b[;H");
    printf("============================================================\n");
    printf("TCP Siren Detection with Wi-Fi Client\n");
    printf("============================================================\n\n");

#if defined (COMPONENT_FREERTOS)
    /* Create the TCP client task */
    result = create_tcp_client_task();
    if (result != CY_RSLT_SUCCESS)
    {
        printf("Failed to create TCP client task!\n");
        CY_ASSERT(0);
    }

    /* Start the FreeRTOS scheduler */
    vTaskStartScheduler();

    /* Should never get here */
    CY_ASSERT(0);

#elif defined (COMPONENT_THREADX)
    /*
    * Start the ThreadX kernel.
    * This routine never returns.
    */

    tx_kernel_enter();

    /* Should never get here. */
    CY_ASSERT(0);
#endif
}

#if defined (COMPONENT_THREADX)
void application_start(void)
{
    tcp_client_task(NULL);
}
#endif

/* [] END OF FILE */
